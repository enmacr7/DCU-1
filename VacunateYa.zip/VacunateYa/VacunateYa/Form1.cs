﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace VacunateYa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Fecha Vacuna Nombre y apellido,cedula, telefono, lat,lng,
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server = JESUS_LAPTOP; database = dbVacunateYa; integrated security = true");
            conexion.Open();
            string Nombre = txtNombre.Text;
            string Cedula = txtCedula.Text;
            string Telefono = txtTelefono.Text;
            string Longitud = txtLongitud.Text;
            string Latitud = txtLatitud.Text;
            string Fecha = txtFecha.Text;
            string Vacuna = txtVacuna.Text;
            string cadena = "insert into V_Registros(Nombre, Cedula, Telefono, Longitud, Latitud, Fecha, Vacuna) " +
            "values ('" + Nombre + "', " + Cedula + ", " + Telefono + ", '" + Longitud + "', '" + Latitud + "', '" + Fecha + "', '" + Vacuna + "')";
            SqlCommand comando = new SqlCommand(cadena, conexion);
            comando.ExecuteNonQuery();
            MessageBox.Show("Los datos han sido registrados.");
            txtLatitud.Text = "";
            txtLongitud.Text = "";
            txtVacuna.Text = "";
            txtFecha.Text = "";
            txtTelefono.Text = "";
            txtCedula.Text = "";
            txtNombre.Text = "";
            conexion.Close();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server = JESUS_LAPTOP; database = dbVacunateYa; integrated security = true");
            conexion.Open();
            string Cedula = txtBuscar.Text;
            string cadena = "select Nombre, Cedula, Telefono, Longitud, Latitud, Fecha, Vacuna from V_Registros where Cedula =" + Cedula;
            SqlCommand comando = new SqlCommand(cadena, conexion);
            SqlDataReader registro = comando.ExecuteReader();
            if (registro.Read())
            {
                txtNombre.Text = registro["Nombre"].ToString();
                txtCedula.Text = registro["Cedula"].ToString();
                txtTelefono.Text = registro["Telefono"].ToString();
                txtLongitud.Text = registro["Longitud"].ToString();
                txtLatitud.Text = registro["Latitud"].ToString();
                txtFecha.Text = registro["Fecha"].ToString();
                txtVacuna.Text = registro["Vacuna"].ToString();
            }
            else
                MessageBox.Show("No existe ningun registro con la cedula de esta persona.");
            conexion.Close();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server = JESUS_LAPTOP; database = dbPractice; integrated security = true");
            conexion.Open();
            string Cedula = txtModificar.Text;
            string NombreM = txtNombre.Text;
            string CedulaM = txtCedula.Text;
            string TelefonoM = txtTelefono.Text;
            string LongitudM = txtLongitud.Text;
            string LatitudM = txtLatitud.Text;
            string FechaM = txtFecha.Text;
            string VacunaM = txtVacuna.Text;
            string cadena = "update V_Registros set Nombre = '" + NombreM + "', Cedula = '" + CedulaM + "', Telefono = '" + TelefonoM + "', Longitud = '" + LongitudM + "', Latitud = '" + LatitudM + "', Fecha = '" + FechaM + "', Vacuna = '" + VacunaM + "' where Cedula = " + Cedula;
            SqlCommand comando = new SqlCommand(cadena, conexion);
            int cant;
            cant = comando.ExecuteNonQuery();
            if (cant == 1)
            {
                MessageBox.Show("Registro modificado");
                txtNombre.Text = "";
                txtCedula.Text = "";
                txtTelefono.Text = "";
                txtLongitud.Text = "";
                txtLatitud.Text = "";
                txtFecha.Text = "";
                txtVacuna.Text = "";
            }
            else
                MessageBox.Show("No existe registro");
            conexion.Close();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtLatitud.Text = "";
            txtLongitud.Text = "";
            txtVacuna.Text = "";
            txtFecha.Text = "";
            txtTelefono.Text = "";
            txtCedula.Text = "";
            txtNombre.Text = "";
            txtModificar.Text = "";
            txtBuscar.Text = "";
            txtTarjeta.Text = "";
        }

        private void btnMapa_Click(object sender, EventArgs e)
        {

        }

        private void btnRegistrar_Click_1(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("server = JESUS_LAPTOP; database = dbVacunateYa; integrated security = true");
            conexion.Open();
            string Nombre = txtNombre.Text;
            string Cedula = txtCedula.Text;
            string Telefono = txtTelefono.Text;
            string Longitud = txtLongitud.Text;
            string Latitud = txtLatitud.Text;
            string Fecha = txtFecha.Text;
            string Vacuna = txtVacuna.Text;
            string cadena = "insert into V_Registros(Nombre, Cedula, Telefono, Longitud, Latitud, Fecha, Vacuna) " +
            "values ('" + Nombre + "', " + Cedula + ", " + Telefono + ", '" + Longitud + "', '" + Latitud + "', '" + Fecha + "', '" + Vacuna + "')";
            SqlCommand comando = new SqlCommand(cadena, conexion);
            comando.ExecuteNonQuery();
            MessageBox.Show("Los datos han sido registrados.");
            txtLatitud.Text = "";
            txtLongitud.Text = "";
            txtVacuna.Text = "";
            txtFecha.Text = "";
            txtTelefono.Text = "";
            txtCedula.Text = "";
            txtNombre.Text = "";
            conexion.Close();
        }
    }
}
